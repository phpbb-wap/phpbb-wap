<?php

define('SHOP_AD_TABLE', $table_prefix.'shop_ad');
define('SHOP_CONFIG_TABLE', $table_prefix.'shop_config');
define('SHOP_QQ_TABLE', $table_prefix.'shop_qq');
define('SHOP_GOOD_TABLE', $table_prefix.'shop_good');

?>