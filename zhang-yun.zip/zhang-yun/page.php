<?php
/**
* @package phpBB-WAP
* @copyright (c) phpBB Group
* @Оптимизация под WAP: Гутник Игорь ( чел ).
* @简体中文：中文phpBB-WAP团队
* @license http://opensource.org/licenses/gpl-license.php
**/

/**
* 这是一款自由软件, 您可以在 Free Software Foundation 发布的
* GNU General Public License 的条款下重新发布或修改; 您可以
* 选择目前 version 2 这个版本（亦可以选择任何更新的版本，由
* 你喜欢）作为新的牌照.
**/

if (defined('IN_PHPBB'))
{
	die('Hacking attempt');
}

define('IN_PHPBB', true);
define('ROOT_PATH', './');

require(ROOT_PATH . 'common.php');

$page_id = get_var('page_id', 0);

$page_id = intval($page_id);

if (!$page_id)
{
	message_die(GENERAL_MESSAGE, '请指定您要访问的页面', '错误');
	// 或
	// redirect(append_sid('index.php', true));
}

$userdata = $session->start($user_ip, PAGE_PAGES);
init_userprefs($userdata);

$sql = 'SELECT page_id, page_title 
	FROM ' . PAGES_TABLE . ' 
	WHERE page_id = ' . $page_id;

if (!$result = $db->sql_query($sql))
{
	message_die(GENERAL_ERROR, '无法查询 ' . PAGES_TABLE . ' 表', '', __LINE__, __FILE__, $sql);
}

if (!$db->sql_numrows($result))
{
	message_die(GENERAL_MESSAGE, '页面不存在', '404');
}

$pages = $db->sql_fetchrow($result);

require (ROOT_PATH . 'includes/class/page_module.php');

$page_module = new page_module;

$page_title = $pages['page_title'];

page_header($page_title);

$page_module->main_module($pages['page_id']);

page_footer();

?>